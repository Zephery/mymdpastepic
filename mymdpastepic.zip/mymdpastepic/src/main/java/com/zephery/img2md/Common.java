package com.zephery.img2md;

/**
 * Created with IntelliJ IDEA.
 * User: Zephery
 * Time: 2017/9/16 14:52
 * Description:
 */
public class Common {
    public final static String COMMON_CODE = "<div align=\"center\">\n" +
            "\n" +
            "PICTUREURL\n" +
            "\n" +
            "</div>" +
            "\n" +
            "\n";
}